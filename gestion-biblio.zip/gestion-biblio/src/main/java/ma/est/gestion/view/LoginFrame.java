package ma.est.gestion.view;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import ma.est.gestion.dao.impl.UtilisateurDaoImpl;
import ma.est.gestion.model.Utilisateur;
import ma.est.gestion.util.DatabaseConnection;

public class LoginFrame extends JFrame {

    private JTextField tfLogin;
    private JPasswordField pfPassword;
    private JTextField tfEmail;
    private JPanel loginPanel;
    private JPanel registerPanel;
    private CardLayout cardLayout;
    private JPanel cardPanel;
    private UtilisateurDaoImpl userDao;
    private JTextField tfRegisterNom;
    private JTextField tfRegisterPrenom;

    public LoginFrame() {

        DatabaseConnection.getConnection();

        userDao = new UtilisateurDaoImpl();

        setTitle("Gestion Bibliothèque - Connexion");
        setSize(850, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Appliquer le style glassmorphisme
        getContentPane().setBackground(new Color(240, 245, 255));
        
        add(header(), BorderLayout.NORTH);
        add(mainContent(), BorderLayout.CENTER);
    }

    private JPanel header() {
        JPanel h = new JPanel();
        h.setOpaque(false);
        JLabel l = new JLabel("Bienvenue dans la Bibliothèque");
        l.setFont(new Font("Arial", Font.BOLD, 24));
        l.setForeground(new Color(60, 80, 120));
        h.add(l);
        h.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        return h;
    }

    private JPanel mainContent() {
        JPanel main = new JPanel(new BorderLayout());
        main.setOpaque(false);
        main.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        cardPanel.setOpaque(false);

        // Panel de connexion
        loginPanel = createLoginPanel();
        
        // Panel d'inscription
        registerPanel = createRegisterPanel();
        
        cardPanel.add(loginPanel, "LOGIN");
        cardPanel.add(registerPanel, "REGISTER");

        // Bouton pour basculer entre connexion et inscription
        JPanel switchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        switchPanel.setOpaque(false);
        
        JLabel switchLabel = new JLabel("Pas encore de compte ? ");
        switchLabel.setForeground(new Color(60, 80, 120));
        
        JButton switchButton = new JButton("Créer un compte");
        switchButton.setBorderPainted(false);
        switchButton.setContentAreaFilled(false);
        switchButton.setForeground(new Color(0, 100, 200));
        switchButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        switchButton.addActionListener(e -> cardLayout.show(cardPanel, "REGISTER"));
        
        switchPanel.add(switchLabel);
        switchPanel.add(switchButton);

        main.add(cardPanel, BorderLayout.CENTER);
        main.add(switchPanel, BorderLayout.SOUTH);

        return main;
    }

    private JPanel createLoginPanel() {
        JPanel panel = createGlassPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel title = new JLabel("Connexion");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(new Color(60, 80, 120));
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(title, gbc);
        
        // Login
        gbc.gridwidth = 1;
        gbc.gridy = 1;
        panel.add(createLabel("Login :"), gbc);
        
        tfLogin = createGlassTextField();
        gbc.gridx = 1;
        panel.add(tfLogin, gbc);
        
        // Mot de passe
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(createLabel("Mot de passe :"), gbc);
        
        pfPassword = new JPasswordField();
        stylizeField(pfPassword);
        gbc.gridx = 1;
        panel.add(pfPassword, gbc);
        
        // Email
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(createLabel("Email :"), gbc);
        
        tfEmail = createGlassTextField();
        gbc.gridx = 1;
        panel.add(tfEmail, gbc);
        
        // Boutons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        
        JButton btnLogin = createGlassButton("Se connecter", new Color(46, 204, 113));
        btnLogin.addActionListener(e -> loginUser());
        
        JButton btnAdmin = createGlassButton("Admin", new Color(52, 152, 219));
        btnAdmin.addActionListener(e -> loginAdmin());
        
        JButton btnBack = createGlassButton("Retour", new Color(149, 165, 166));
        btnBack.addActionListener(e -> {
            // Fermer cette fenêtre et revenir au LoginFrame principal
            dispose();
            new LoginFrame().setVisible(true);
        });
        
        buttonPanel.add(btnLogin);
        buttonPanel.add(btnAdmin);
        buttonPanel.add(btnBack);
        
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(buttonPanel, gbc);
        
        return panel;
    }

    private JPanel createRegisterPanel() {
        JPanel panel = createGlassPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel title = new JLabel("Créer un compte");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(new Color(60, 80, 120));
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(title, gbc);
        
        // Champs d'inscription
        JTextField tfRegisterLogin = createGlassTextField();
        JPasswordField pfRegisterPassword = new JPasswordField();
        JPasswordField pfConfirmPassword = new JPasswordField();
        JTextField tfRegisterEmail = createGlassTextField();
        tfRegisterNom = createGlassTextField();
        tfRegisterPrenom = createGlassTextField();

        
        stylizeField(pfRegisterPassword);
        stylizeField(pfConfirmPassword);
        
        // Login
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(createLabel("Login :"), gbc);
        
        gbc.gridx = 1;
        panel.add(tfRegisterLogin, gbc);

        // Nom 
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(createLabel("Nom :"), gbc);

        gbc.gridx = 1;
        panel.add(tfRegisterNom, gbc);

        // Prénom
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(createLabel("Prénom :"), gbc);

        gbc.gridx = 1;
        panel.add(tfRegisterPrenom, gbc);

        // Mot de passe
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(createLabel("Mot de passe :"), gbc);
        
        gbc.gridx = 1;
        panel.add(pfRegisterPassword, gbc);
        
        // Confirmer mot de passe
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(createLabel("Confirmer :"), gbc);
        
        gbc.gridx = 1;
        panel.add(pfConfirmPassword, gbc);
        
        // Email
        gbc.gridx = 0;
        gbc.gridy = 7;
        panel.add(createLabel("Email :"), gbc);
        
        gbc.gridx = 1;
        panel.add(tfRegisterEmail, gbc);



        
        // Boutons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setOpaque(false);
        
        JButton btnRegister = createGlassButton("S'inscrire", new Color(155, 89, 182));
        btnRegister.addActionListener(e -> registerUser(
            tfRegisterLogin.getText(),
            tfRegisterNom.getText(),
            tfRegisterPrenom.getText(),
            new String(pfRegisterPassword.getPassword()),
            new String(pfConfirmPassword.getPassword()),
            tfRegisterEmail.getText()
        ));
        
        JButton btnBackToLogin = createGlassButton("Retour", new Color(149, 165, 166));
        btnBackToLogin.addActionListener(e -> cardLayout.show(cardPanel, "LOGIN"));
        
        buttonPanel.add(btnRegister);
        buttonPanel.add(btnBackToLogin);
        
        gbc.gridwidth = 2;
        gbc.gridx = 0;
        gbc.gridy = 8;
        panel.add(buttonPanel, gbc);
        
        return panel;
    }

private void loginUser() {
    String login = tfLogin.getText();
    String password = new String(pfPassword.getPassword());

    if (login.isEmpty() || password.isEmpty()) {
        JOptionPane.showMessageDialog(this,
            "Veuillez remplir tous les champs",
            "Erreur",
            JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Authentification via DAO
    Utilisateur u = userDao.authentifier(login, password);

    if (u != null) {
        // Récupérer l'email depuis la base
        String email = userDao.getEmailAdherent(u.getNumAdherent());

        // Fermer la fenêtre de connexion
        this.dispose();

        // Ouvrir la fenêtre utilisateur
        new UtilisateurPanel(u.getLogin(), email, Integer.parseInt(u.getNumAdherent())).setVisible(true);

    } else {
        JOptionPane.showMessageDialog(this,
            "Échec de la connexion. Vérifiez vos identifiants.",
            "Erreur",
            JOptionPane.ERROR_MESSAGE);
    }
}
    private void loginAdmin() {
        String login = tfLogin.getText();
        String pwd = new String(pfPassword.getPassword());

        Utilisateur u = userDao.authentifier(login, pwd);

        if ("admin".equals(login) && "admin".equals(pwd) ||
                (u != null && "ADMIN".equals(u.getRole().getNomRole()))) {

            dispose();
            new MainFrame().setVisible(true);

        } else {
            JOptionPane.showMessageDialog(this,
                    "Accès refusé. Vérifiez vos identifiants admin.",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void registerUser(String login, String nom, String prenom, String password, String confirmPassword, String email) {
        // Validation des champs
        try {
        if (login.isEmpty() || nom.isEmpty() || prenom.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Tous les champs sont obligatoires",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this,
                    "Les mots de passe ne correspondent pas",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!email.contains("@")) {
            JOptionPane.showMessageDialog(this,
                    "Email invalide",
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        /*
        JButton btnRegister = createGlassButton("S'inscrire", new Color(155, 89, 182));
        btnRegister.addActionListener(e -> registerUser(
            tfRegisterLogin.getText(),
            tfRegisterNom.getText(),
            tfRegisterPrenom.getText(),
            new String(pfRegisterPassword.getPassword()),
            new String(pfConfirmPassword.getPassword()),
            tfRegisterEmail.getText()
        ));
        */

        String sqlAdherent = "INSERT INTO adherents (nom, prenom, email) VALUES (?, ?, ?)";
        String sqlUser = "INSERT INTO utilisateur (login, password, statut, role, numAdherent) VALUES (?, ?, ?, ?, ?)";

        Connection con = DatabaseConnection.getConnection();

        try {
            con.setAutoCommit(false); // transaction

            // 1️⃣ Insert adherent
            PreparedStatement psAdh = con.prepareStatement(
                    sqlAdherent,
                    PreparedStatement.RETURN_GENERATED_KEYS
            );

            psAdh.setString(1, nom);
            psAdh.setString(2, prenom);
            psAdh.setString(3, email);
            psAdh.executeUpdate();

            // 2️⃣ Récupérer l'id généré
            ResultSet rs = psAdh.getGeneratedKeys();
            if (!rs.next()) {
                throw new SQLException("Impossible de récupérer l'id adherent");
            }

            int numAdherent = rs.getInt(1);

            // 3️⃣ Insert utilisateur avec l'id adherent
            PreparedStatement psUser = con.prepareStatement(sqlUser);
            psUser.setString(1, login);
            psUser.setString(2, password);
            psUser.setString(3, "ACTIF");
            psUser.setString(4, "USER");
            psUser.setInt(5, numAdherent);
            psUser.executeUpdate();

            con.commit(); // ✅ tout est OK

        } catch (Exception e) {
            try { con.rollback(); } catch (SQLException ex) {}
            JOptionPane.showMessageDialog(this,
                    "Erreur lors de l'inscription : " + e.getMessage(),
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur inattendue : " + e.getMessage(),
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
    

        
        // Simuler l'inscription (dans une vraie application, sauvegarder en base)
        JOptionPane.showMessageDialog(this,
                "Compte créé avec succès!\nVous pouvez maintenant vous connecter.",
                "Succès",
                JOptionPane.INFORMATION_MESSAGE);
        
        // Retour à l'écran de connexion
        cardLayout.show(cardPanel, "LOGIN");
        
        // Pré-remplir les champs de connexion
        tfLogin.setText(login);
        tfEmail.setText(email);
        pfPassword.setText("");
    }

    // Méthodes utilitaires pour le style glassmorphisme
    private JPanel createGlassPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Effet glassmorphisme
                int arc = 20;
                Color background = new Color(255, 255, 255, 180);
                Color border = new Color(255, 255, 255, 200);
                
                g2d.setColor(background);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), arc, arc);
                
                g2d.setColor(border);
                g2d.setStroke(new BasicStroke(1.5f));
                g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, arc, arc);
                
                g2d.dispose();
            }
        };
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        return panel;
    }

    private JTextField createGlassTextField() {
        JTextField field = new JTextField(20);
        stylizeField(field);
        return field;
    }

    private void stylizeField(JComponent field) {
        field.setPreferredSize(new Dimension(200, 35));
        field.setFont(new Font("Arial", Font.PLAIN, 14));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 220, 200), 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        field.setOpaque(false);
        field.setBackground(new Color(255, 255, 255, 150));
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setForeground(new Color(60, 80, 120));
        return label;
    }

    private JButton createGlassButton(String text, Color color) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Fond avec transparence
                if (getModel().isPressed()) {
                    g2d.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 200));
                } else if (getModel().isRollover()) {
                    g2d.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 180));
                } else {
                    g2d.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 150));
                }
                
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2d.dispose();
                
                super.paintComponent(g);
            }
        };
        
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        return button;
    }
}