package ma.est.gestion.controller;

public class AuthController {
    
}