package ma.est.gestion.view;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableModel;

public class LivrePanel extends JFrame {

    //TABLE
    private JTable table;

    // BOUTONS HEADER
    private JButton btnAjouter;
    private JButton btnSupp;
    private JButton btnGereAdh;
    private JButton btnGereEmp;
    private JButton btnRetour;

    //FORMULAIRE 
    private JPanel formPanel;
    private JTextField tfCode;
    private JTextField tfTitre;
    private JTextField tfAuteur;
    private JTextField tfEx;
    private JComboBox<String> cbCategorie;
    private JButton btnValiderForm;

    // CATEGORIE
    private JButton btnSelectCat;

    public LivrePanel() {

        setTitle("Gestion Bibliothèque - Admin");
        setSize(1350, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new BorderLayout());
        
        // Appliquer le style glassmorphisme
        getContentPane().setBackground(new Color(240, 245, 255));

        //HEADER avec effet glass
        JPanel header = createGlassPanel();
        header.setLayout(new BorderLayout());
        header.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel title = new JLabel("Gestion des Livres");
        title.setForeground(new Color(60, 80, 120));
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));

        JPanel headerBtns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        headerBtns.setOpaque(false);

        btnAjouter = createGlassButton("Ajouter", new Color(46, 204, 113));
        btnSupp = createGlassButton("Supprimer", new Color(231, 76, 60));
        btnGereAdh = createGlassButton("Gérer adhérents", new Color(52, 152, 219));
        btnGereEmp = createGlassButton("Gérer emprunts", new Color(241, 196, 15));
        btnRetour = createGlassButton("Retour accueil", new Color(149, 165, 166));

        btnRetour.addActionListener(e -> {
            java.awt.Window win = javax.swing.SwingUtilities.getWindowAncestor((java.awt.Component)e.getSource());
            if (win != null) win.dispose();
            new LoginFrame().setVisible(true);
        });

        headerBtns.add(btnAjouter);
        headerBtns.add(btnSupp);
        headerBtns.add(btnGereAdh);
        headerBtns.add(btnGereEmp);
        headerBtns.add(btnRetour);

        header.add(title, BorderLayout.WEST);
        header.add(headerBtns, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // TABLE avec effet glass
        table = new JTable();
        JScrollPane scroll = new JScrollPane(table);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        scroll.getViewport().setBackground(new Color(255, 255, 255, 180));
        
        JPanel tablePanel = createGlassPanel();
        tablePanel.setLayout(new BorderLayout());
        tablePanel.add(scroll, BorderLayout.CENTER);
        
        add(tablePanel, BorderLayout.CENTER);

        // FORMULAIRE avec effet glass
        formPanel = createGlassPanel();
        formPanel.setLayout(new GridLayout(6, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 220, 200)),
            "Informations du livre"
        ));

        tfCode = createGlassTextField();
        tfTitre = createGlassTextField();
        tfAuteur = createGlassTextField();
        tfEx = createGlassTextField();

        cbCategorie = new JComboBox<>();
        cbCategorie.setEditable(true);
        cbCategorie.setBackground(new Color(255, 255, 255, 150));

        formPanel.add(createFormLabel("Code"));
        formPanel.add(tfCode);
        formPanel.add(createFormLabel("Titre"));
        formPanel.add(tfTitre);
        formPanel.add(createFormLabel("Auteur"));
        formPanel.add(tfAuteur);
        formPanel.add(createFormLabel("Nombre d'exemplaires"));
        formPanel.add(tfEx);

        btnValiderForm = createGlassButton("Valider", new Color(155, 89, 182));

        JPanel rightPanel = new JPanel(new BorderLayout(5, 5));
        rightPanel.setOpaque(false);
        rightPanel.add(formPanel, BorderLayout.CENTER);
        rightPanel.add(btnValiderForm, BorderLayout.SOUTH);

        formPanel.setVisible(false);
        add(rightPanel, BorderLayout.EAST);

        //FOOTER avec effet glass
        btnSelectCat = createGlassButton("Ajouter une catégorie", new Color(52, 73, 94));

        JPanel bottom = createGlassPanel();
        bottom.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        
        JLabel catLabel = createFormLabel("Catégories :");
        bottom.add(catLabel);
        
        cbCategorie.setPreferredSize(new Dimension(150, 35));
        bottom.add(cbCategorie);
        bottom.add(btnSelectCat);

        add(bottom, BorderLayout.SOUTH);


    }

    // Méthodes pour le style glassmorphisme

    private JPanel createGlassPanel() {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                Color background = new Color(255, 255, 255, 180);
                Color border = new Color(255, 255, 255, 200);
                
                g2d.setColor(background);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                
                g2d.setColor(border);
                g2d.setStroke(new BasicStroke(1.5f));
                g2d.drawRect(0, 0, getWidth() - 1, getHeight() - 1);
                
                g2d.dispose();
            }
        };
        panel.setOpaque(false);
        return panel;
    }

    private JTextField createGlassTextField() {
        JTextField field = new JTextField();
        field.setPreferredSize(new Dimension(150, 35));
        field.setBackground(new Color(255, 255, 255, 150));
        field.setForeground(new Color(60, 80, 120));
        field.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 220, 200), 1),
            BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        return field;
    }

    private JLabel createFormLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(new Color(60, 80, 120));
        label.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        return label;
    }

    private JButton createGlassButton(String text, Color color) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                if (getModel().isPressed()) {
                    g2d.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 200));
                } else if (getModel().isRollover()) {
                    g2d.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 180));
                } else {
                    g2d.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 150));
                }
                
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2d.dispose();
                
                super.paintComponent(g);
            }
        };
        
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(Color.WHITE);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    //GETTERS 
    public JTable getTable() { return table; }

    public JButton getBtnAjouter() { return btnAjouter; }
    public JButton getBtnSupp() { return btnSupp; }
    public JButton getBtnGereAdh() { return btnGereAdh; }
    public JButton getBtnGereEmp() { return btnGereEmp; }
    public JButton getBtnRetour() { return btnRetour; }

    public JButton getBtnValiderForm() { return btnValiderForm; }
    public JPanel getFormPanel() { return formPanel; }

    public JTextField getTfCode() { return tfCode; }
    public JTextField getTfTitre() { return tfTitre; }
    public JTextField getTfAuteur() { return tfAuteur; }
    public JTextField getTfEx() { return tfEx; }
    public JComboBox<String> getCbCategorie() { return cbCategorie; }

    public JButton getBtnSelectCat() { return btnSelectCat; }

    public void setTableModel(TableModel model) {
        table.setModel(model);
        table.getTableHeader().setBackground(new Color(70, 130, 180, 180));
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
    }
}